# Code of Conduct

HashiCorp Community Guidelines apply to you when interacting with the community here on GitHub and contributing code.

Please read the full text at https://www.hashicorp.com/community-guidelines
